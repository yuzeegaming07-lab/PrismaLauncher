# Prisma Launcher

Android-first starter project for a free Minecraft Bedrock content manager, using a custom dark/lavender Prisma identity.

## Current starter features
- Jetpack Compose dashboard with Home, Versions, Packs, Settings.
- Import `.mcpack`, `.mcaddon`, and `.mcworld` through Android Storage Access Framework.
- Store imported files in app-private storage.
- Share an imported package to Android's app chooser so Minecraft can handle it when the installed version supports the package.
- No premium tier, payment SDK, ads SDK, or account requirement.

## Important technical boundaries
This project is a **starter content manager**, not a replacement for Minecraft and not yet a full game launcher.
- It does not include Minecraft binaries, bypass licensing, or download unofficial APKs.
- Android does not provide a public API that lets a third-party launcher install every historical Bedrock version. Version availability and downgrade restrictions are controlled by the official store/platform.
- Shader support depends on the Bedrock version, rendering pipeline, and device. A pack being importable does not guarantee it will work.
- Android package sharing uses the system chooser. The user must select Minecraft if Android offers it.
- The current import list is app-private. A later release should add pack metadata parsing, validation, duplicate detection, and explicit delete/export controls.

## Build
1. Install Android Studio (recent stable) and Android SDK 35 (the app targets API 35 and is installable on Android 7.0+; newer Android releases, including Android 16, support apps targeting API 35).
2. Open this folder as a Gradle project.
3. Use JDK 17.
4. Sync Gradle, then run the `app` configuration on an Android device/emulator (API 24+ (Android 7.0 Nougat through Android 16 and newer, subject to device compatibility)).

## Next milestones
1. FileProvider is already registered in the application manifest; verify it remains enabled if you customize the package name.
2. Parse `manifest.json` inside `.mcpack` / `.mcaddon` archives and show pack name, UUID, version, and dependencies.
3. Add pack categories, search, favorites, delete/export, and compatibility notes.
4. Add per-world behavior/resource pack activation guidance.
5. Build Windows/Linux/macOS clients with a shared Kotlin Multiplatform core or a separate desktop UI.
6. Add automated tests and CI.

## FileProvider configuration
The AndroidX FileProvider is already registered in `AndroidManifest.xml` inside `<application>`:

```xml
<provider
    android:name="androidx.core.content.FileProvider"
    android:authorities="${applicationId}.fileprovider"
    android:exported="false"
    android:grantUriPermissions="true">
    <meta-data
        android:name="android.support.FILE_PROVIDER_PATHS"
        android:resource="@xml/file_paths" />
</provider>
```

The provider is intentionally called out as a setup step in this starter to make the integration explicit.
