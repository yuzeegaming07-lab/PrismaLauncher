package id.prisma.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

private val Ink = Color(0xFF171620)
private val Panel = Color(0xFF292735)
private val Panel2 = Color(0xFF343241)
private val Lavender = Color(0xFFC4BFFF)
private val Muted = Color(0xFFAAA7B9)

class MainActivity : ComponentActivity() {
    private lateinit var packStore: PackStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        packStore = PackStore(filesDir)
        setContent {
            PrismaTheme {
                PrismaApp(
                    packStore = packStore,
                    onImport = { uri -> importPack(uri) },
                    onOpenMinecraft = { file -> shareToMinecraft(file) }
                )
            }
        }
    }

    private fun importPack(uri: Uri) {
        contentResolver.openInputStream(uri)?.use { input ->
            val name = queryDisplayName(uri) ?: "import-${System.currentTimeMillis()}.mcpack"
            val safeName = name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            val target = File(packStore.importDir, safeName)
            FileOutputStream(target).use { output -> input.copyTo(output) }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) return cursor.getString(0)
            }
        return uri.lastPathSegment
    }

    private fun shareToMinecraft(file: File) {
        // Android/Minecraft decides whether it can handle this Bedrock package.
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = when (file.extension.lowercase()) {
                "mcpack" -> "application/zip"
                "mcaddon" -> "application/zip"
                "mcworld" -> "application/zip"
                else -> "application/octet-stream"
            }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Buka dengan Minecraft"))
    }
}

@Composable
private fun PrismaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink, surface = Panel, primary = Lavender,
            onPrimary = Color(0xFF24213A), onBackground = Color.White,
            onSurface = Color.White, secondary = Lavender
        ),
        content = content
    )
}

@Composable
private fun PrismaApp(
    packStore: PackStore,
    onImport: (Uri) -> Unit,
    onOpenMinecraft: (File) -> Unit
) {
    var page by remember { mutableStateOf("Home") }
    var refresh by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImport(uri)
            refresh++
        }
    }
    val packs = remember(refresh) { packStore.listImports() }

    Scaffold(
        containerColor = Ink,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Versions", "Packs", "Settings").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = {
                            Icon(
                                when (item) {
                                    "Home" -> Icons.Default.Home
                                    "Versions" -> Icons.Default.Extension
                                    "Packs" -> Icons.Default.Layers
                                    else -> Icons.Default.Settings
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Lavender,
                            selectedTextColor = Lavender,
                            indicatorColor = Panel2,
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 18.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Prisma Launcher", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Lavender)
                    Text("Minecraft Bedrock Edition", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Lavender)
            }
            when (page) {
                "Home" -> HomePage(packs.size, onGoPacks = { page = "Packs" })
                "Versions" -> VersionsPage()
                "Packs" -> PacksPage(packs, onImport = {
                    picker.launch(arrayOf(
                        "application/octet-stream", "application/zip",
                        "application/x-zip-compressed"
                    ))
                }, onOpen = onOpenMinecraft)
                else -> SettingsPage()
            }
        }
    }
}

@Composable
private fun HomePage(packCount: Int, onGoPacks: () -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Imported packs", packCount.toString(), Modifier.weight(1f))
                StatCard("Premium", "Never", Modifier.weight(1f))
            }
        }
        item {
            PanelCard {
                Text("Welcome to your world", color = Muted, fontSize = 13.sp)
                Text("Play your way.", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Kelola konten Bedrock dari satu tempat. Minecraft resmi tetap diperlukan untuk bermain.",
                    color = Muted
                )
                Button(
                    onClick = onGoPacks,
                    colors = ButtonDefaults.buttonColors(containerColor = Lavender),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Kelola Add-on & Resource Pack", color = Ink) }
            }
        }
        item {
            PanelCard {
                Text("Quick access", fontWeight = FontWeight.Bold)
                QuickRow(Icons.Default.Extension, "Add-on Manager", "Impor .mcaddon / .mcpack")
                QuickRow(Icons.Default.Image, "Resource Packs", "Paket tekstur Bedrock")
                QuickRow(Icons.Default.AutoAwesome, "Shader Manager", "Pack grafis yang kompatibel")
            }
        }
        item {
            Text(
                "Catatan: Prisma adalah pengelola konten, bukan salinan Minecraft.",
                color = Muted, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun VersionsPage() {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            PanelCard {
                Text("Version Manager", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Versi game Bedrock didistribusikan melalui toko/platform resmi. Android membatasi pemasangan downgrade dan beberapa versi lama.",
                    color = Muted
                )
                Text("Rencana fitur", color = Lavender, fontWeight = FontWeight.Bold)
                QuickRow(Icons.Default.Download, "Official version", "Buka Google Play / Microsoft Store")
                QuickRow(Icons.Default.History, "Version profiles", "Simpan preset pack per versi (roadmap)")
                QuickRow(Icons.Default.Info, "Compatibility", "Periksa dukungan pack sebelum impor")
            }
        }
        item {
            Text("Prisma tidak mengunduh APK game dari mirror tidak resmi atau melewati lisensi Minecraft.", color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PacksPage(
    packs: List<File>,
    onImport: () -> Unit,
    onOpen: (File) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PanelCard {
            Text("Content Manager", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Impor file Bedrock milikmu. Pilih file .mcpack, .mcaddon, atau .mcworld.", color = Muted)
            Button(
                onClick = onImport,
                colors = ButtonDefaults.buttonColors(containerColor = Lavender),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Ink)
                Spacer(Modifier.width(8.dp))
                Text("Impor pack", color = Ink)
            }
        }
        Text("Imported files (${packs.size})", color = Lavender, fontWeight = FontWeight.Bold)
        if (packs.isEmpty()) {
            PanelCard {
                Text("Belum ada file", fontWeight = FontWeight.SemiBold)
                Text("Tekan Impor pack untuk memilih file dari penyimpanan perangkat.", color = Muted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(packs, key = { it.absolutePath }) { file ->
                    PanelCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                when (file.extension.lowercase()) {
                                    "mcworld" -> Icons.Default.Public
                                    else -> Icons.Default.Layers
                                }, contentDescription = null, tint = Lavender
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(file.name, fontWeight = FontWeight.SemiBold)
                                Text("${file.extension.uppercase()} • ${file.length() / 1024} KB", color = Muted, fontSize = 11.sp)
                            }
                            IconButton(onClick = { onOpen(file) }) {
                                Icon(Icons.Default.Share, contentDescription = "Open with Minecraft", tint = Lavender)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsPage() {
    PanelCard {
        Text("Settings", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        QuickRow(Icons.Default.Palette, "Appearance", "Prisma Dark • Lavender")
        QuickRow(Icons.Default.Security, "Privacy", "File access only when you choose")
        QuickRow(Icons.Default.Info, "About", "Prisma Launcher 0.1.0 • Free & open source")
        Text("Tidak ada premium, iklan, atau fitur berbayar pada starter project ini.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, fontSize = 12.sp)
            Text(value, fontSize = 25.sp, color = Lavender, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun QuickRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = Lavender)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

private class PackStore(private val appFiles: File) {
    val importDir: File = File(appFiles, "prisma/imports").apply { mkdirs() }

    fun listImports(): List<File> =
        importDir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
}
